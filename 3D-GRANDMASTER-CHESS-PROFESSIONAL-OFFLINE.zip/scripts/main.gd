extends Control

const LIGHT := Color("#e6d4b5")
const DARK := Color("#71513b")
const GOLD := Color("#d7ae68")
const BG := Color("#0d1119")
const PANEL := Color("#171e2a")
const WHITE_PIECES := {"K":"♔","Q":"♕","R":"♖","B":"♗","N":"♘","P":"♙"}
const BLACK_PIECES := {"K":"♚","Q":"♛","R":"♜","B":"♝","N":"♞","P":"♟"}
const VALUES := {"P":100,"N":320,"B":330,"R":500,"Q":900,"K":20000}

var board: Array = []
var turn := "w"
var selected := Vector2i(-1,-1)
var legal_targets: Array[Vector2i] = []
var history: Array[String] = []
var move_log: Array[String] = []
var en_passant := Vector2i(-1,-1)
var castle := {"wK":true,"wQ":true,"bK":true,"bQ":true}
var game_over := false
var vs_computer := true
var computer_side := "b"
var difficulty := 2
var white_seconds := 600.0
var black_seconds := 600.0
var clock_running := false
var board_buttons: Array[Button] = []
var status_label: Label
var turn_label: Label
var log_label: RichTextLabel
var clock_label: Label
var screen_root: Control
var page := "welcome"
var sound_on := true
var theme_name := "ROYAL GOLD"
var theme_names := ["ROYAL GOLD","AMOLED BLACK","EMERALD","PURPLE","WOOD"]
var theme_accent := GOLD
var thinking := false

func _ready() -> void:
    get_viewport().size_changed.connect(_layout_refresh)
    _show_welcome()

func _layout_refresh() -> void:
    if page == "game":
        _show_game()
    elif page == "home":
        _show_home()

func _clear() -> void:
    for child in get_children():
        child.queue_free()
    screen_root = Control.new()
    screen_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(screen_root)

func _label(parent: Control, text: String, pos: Vector2, size: Vector2, fs: int, color := Color.WHITE, align := HORIZONTAL_ALIGNMENT_LEFT) -> Label:
    var l := Label.new()
    l.text = text
    l.position = pos
    l.size = size
    l.add_theme_font_size_override("font_size", fs)
    l.add_theme_color_override("font_color", color)
    l.horizontal_alignment = align
    l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    parent.add_child(l)
    return l

func _button(parent: Control, text: String, pos: Vector2, size: Vector2, cb: Callable, primary := false) -> Button:
    var b := Button.new()
    b.text = text
    b.position = pos
    b.size = size
    b.add_theme_font_size_override("font_size", 20)
    var st := StyleBoxFlat.new()
    st.bg_color = theme_accent if primary else PANEL
    st.corner_radius_top_left = 15
    st.corner_radius_top_right = 15
    st.corner_radius_bottom_left = 15
    st.corner_radius_bottom_right = 15
    st.border_width_bottom = 1
    st.border_color = Color(1,1,1,0.12)
    b.add_theme_stylebox_override("normal", st)
    b.add_theme_stylebox_override("hover", st)
    b.add_theme_stylebox_override("pressed", st)
    b.add_theme_color_override("font_color", Color("#17130d") if primary else Color("#f4f0e8"))
    b.pressed.connect(cb)
    parent.add_child(b)
    return b

func _panel(parent: Control, pos: Vector2, size: Vector2) -> Panel:
    var p := Panel.new()
    p.position = pos
    p.size = size
    var st := StyleBoxFlat.new()
    st.bg_color = PANEL
    st.corner_radius_top_left = 22
    st.corner_radius_top_right = 22
    st.corner_radius_bottom_left = 22
    st.corner_radius_bottom_right = 22
    st.border_width_left = 1
    st.border_width_right = 1
    st.border_width_top = 1
    st.border_width_bottom = 1
    st.border_color = Color(1,1,1,0.10)
    p.add_theme_stylebox_override("panel", st)
    parent.add_child(p)
    return p

func _show_welcome() -> void:
    page = "welcome"
    _clear()
    _label(screen_root, "♛", Vector2(0,250), Vector2(1080,180), 145, GOLD, HORIZONTAL_ALIGNMENT_CENTER)
    _label(screen_root, "3D GRANDMASTER", Vector2(30,445), Vector2(1020,80), 52, Color("#f7f0e4"), HORIZONTAL_ALIGNMENT_CENTER)
    _label(screen_root, "CHESS", Vector2(30,520), Vector2(1020,75), 48, GOLD, HORIZONTAL_ALIGNMENT_CENTER)
    _label(screen_root, "A focused offline chess experience", Vector2(50,635), Vector2(980,50), 23, Color("#c9c3b8"), HORIZONTAL_ALIGNMENT_CENTER)
    _panel(screen_root, Vector2(65,790), Vector2(950,300))
    _label(screen_root, "PLAY  •  TRAIN  •  IMPROVE", Vector2(95,835), Vector2(890,55), 27, GOLD, HORIZONTAL_ALIGNMENT_CENTER)
    _label(screen_root, "Local chess, computer opponent, move history,\nchess lessons and tactical practice.", Vector2(110,910), Vector2(860,100), 21, Color("#e9e5dc"), HORIZONTAL_ALIGNMENT_CENTER)
    _button(screen_root, "ENTER GRANDMASTER  →", Vector2(145,1190), Vector2(790,90), _show_home, true)
    _label(screen_root, "OFFLINE EDITION  •  NO ACCOUNT REQUIRED", Vector2(80,1700), Vector2(920,55), 16, Color("#9b9b9b"), HORIZONTAL_ALIGNMENT_CENTER)

func _show_home() -> void:
    page = "home"
    _clear()
    _label(screen_root, "♛  GRANDMASTER", Vector2(55,70), Vector2(900,65), 39, GOLD)
    _label(screen_root, "Choose your next move.", Vector2(58,145), Vector2(900,50), 21, Color("#c8c4bd"))
    _panel(screen_root, Vector2(45,250), Vector2(990,235))
    _label(screen_root, "YOUR CHESS JOURNEY", Vector2(80,280), Vector2(900,50), 24, GOLD)
    _label(screen_root, "Play a full game, practise tactics, or build your fundamentals.", Vector2(80,340), Vector2(900,65), 19)
    _button(screen_root, "NEW GAME  →", Vector2(80,410), Vector2(400,55), _new_game, true)
    var entries := [
        ["PLAY & MODES","Computer opponent and local two-player",Callable(self,"_new_game")],
        ["CHESS ACADEMY","Rules, strategy and learning path",Callable(self,"_academy")],
        ["TACTICS TRAINING","Practice tactical patterns",Callable(self,"_puzzles")],
        ["THEME STUDIO","Choose your board appearance",Callable(self,"_themes")],
        ["PLAYER STATS","Local game record and progress",Callable(self,"_stats")],
        ["SETTINGS","Difficulty, clocks and sound",Callable(self,"_settings")]
    ]
    for i in range(entries.size()):
        var x := 45 + (i % 2) * 505
        var y := 555 + int(i / 2) * 190
        _panel(screen_root, Vector2(x,y), Vector2(480,160))
        _label(screen_root, entries[i][0], Vector2(x+25,y+18), Vector2(430,42), 22, GOLD)
        _label(screen_root, entries[i][1], Vector2(x+25,y+60), Vector2(430,45), 16, Color("#e5e0d7"))
        _button(screen_root, "OPEN  →", Vector2(x+25,y+112), Vector2(200,38), entries[i][2])
    _label(screen_root, "OFFLINE • PRIVATE • NO ONLINE MATCHMAKING", Vector2(55,1725), Vector2(970,45), 15, Color("#9299a4"), HORIZONTAL_ALIGNMENT_CENTER)

func _new_game() -> void:
    _reset_board()
    _show_game()

func _reset_board() -> void:
    board = [
        ["bR","bN","bB","bQ","bK","bB","bN","bR"],
        ["bP","bP","bP","bP","bP","bP","bP","bP"],
        ["","","","","","","",""],
        ["","","","","","","",""],
        ["","","","","","","",""],
        ["","","","","","","",""],
        ["wP","wP","wP","wP","wP","wP","wP","wP"],
        ["wR","wN","wB","wQ","wK","wB","wN","wR"]
    ]
    turn = "w"
    selected = Vector2i(-1,-1)
    legal_targets.clear()
    history.clear()
    move_log.clear()
    en_passant = Vector2i(-1,-1)
    castle = {"wK":true,"wQ":true,"bK":true,"bQ":true}
    game_over = false
    white_seconds = 600
    black_seconds = 600
    clock_running = true
    thinking = false
    _refresh_board()

func _show_game() -> void:
    page = "game"
    _clear()
    _label(screen_root, "← BACK", Vector2(35,35), Vector2(180,55), 20, GOLD)
    _button(screen_root, "DASHBOARD", Vector2(820,35), Vector2(220,55), _show_home)
    _label(screen_root, "WHITE  •  " + _clock_text(white_seconds), Vector2(45,145), Vector2(480,60), 24, Color("#f4eee3"))
    _label(screen_root, "BLACK  •  " + _clock_text(black_seconds), Vector2(555,145), Vector2(480,60), 24, Color("#d0d0d0"), HORIZONTAL_ALIGNMENT_RIGHT)
    turn_label = _label(screen_root, "WHITE TO MOVE", Vector2(50,225), Vector2(980,55), 24, GOLD, HORIZONTAL_ALIGNMENT_CENTER)
    _panel(screen_root, Vector2(35,310), Vector2(1010,1010))
    var grid := GridContainer.new()
    grid.columns = 8
    grid.position = Vector2(75,350)
    grid.size = Vector2(930,930)
    grid.add_theme_constant_override("h_separation", 0)
    grid.add_theme_constant_override("v_separation", 0)
    screen_root.add_child(grid)
    board_buttons.clear()
    for r in range(8):
        for c in range(8):
            var b := Button.new()
            b.custom_minimum_size = Vector2(116,116)
            b.size = Vector2(116,116)
            b.add_theme_font_size_override("font_size", 63)
            b.add_theme_color_override("font_color", Color("#fffaf0"))
            b.add_theme_color_override("font_hover_color", Color("#fffaf0"))
            var st := StyleBoxFlat.new()
            st.bg_color = LIGHT if (r+c)%2 == 0 else DARK
            st.set_corner_radius_all(0)
            b.add_theme_stylebox_override("normal", st)
            b.add_theme_stylebox_override("hover", st)
            b.add_theme_stylebox_override("pressed", st)
            var sq := Vector2i(r,c)
            b.pressed.connect(func(): _on_square(sq))
            grid.add_child(b)
            board_buttons.append(b)
    status_label = _label(screen_root, "Select a piece to see legal moves.", Vector2(55,1350), Vector2(970,60), 18, Color("#e4e0d7"), HORIZONTAL_ALIGNMENT_CENTER)
    _panel(screen_root, Vector2(50,1430), Vector2(980,230))
    log_label = RichTextLabel.new()
    log_label.position = Vector2(75,1450)
    log_label.size = Vector2(930,135)
    log_label.add_theme_font_size_override("normal_font_size", 17)
    log_label.add_theme_color_override("default_color", Color("#eee8dd"))
    screen_root.add_child(log_label)
    _button(screen_root, "UNDO", Vector2(55,1680), Vector2(210,60), _undo)
    _button(screen_root, "NEW GAME", Vector2(300,1680), Vector2(250,60), _new_game)
    _button(screen_root, "HINT", Vector2(580,1680), Vector2(210,60), _hint)
    _button(screen_root, "RESIGN", Vector2(815,1680), Vector2(210,60), _resign)
    _refresh_board()

func _refresh_board() -> void:
    if page != "game" or board_buttons.size() != 64:
        return
    for r in range(8):
        for c in range(8):
            var idx := r*8+c
            var b: Button = board_buttons[idx]
            var piece: String = board[r][c]
            b.text = ""
            if piece != "":
                b.text = WHITE_PIECES[piece.substr(1,1)] if piece.begins_with("w") else BLACK_PIECES[piece.substr(1,1)]
            var st := StyleBoxFlat.new()
            var col := LIGHT if (r+c)%2 == 0 else DARK
            if selected == Vector2i(r,c):
                col = Color("#d8b65f")
            elif Vector2i(r,c) in legal_targets:
                col = Color("#8b9f6a") if (r+c)%2 == 0 else Color("#587044")
            st.bg_color = col
            b.add_theme_stylebox_override("normal", st)
            b.add_theme_stylebox_override("hover", st)
            b.add_theme_stylebox_override("pressed", st)
    if turn_label:
        turn_label.text = ("WHITE" if turn=="w" else "BLACK") + " TO MOVE" + ("  •  COMPUTER THINKING" if thinking else "")
    if log_label:
        log_label.clear()
        for i in range(move_log.size()):
            log_label.append_text(("%d. " % (i/2+1)) if i%2==0 else "")
            log_label.append_text(move_log[i] + ("     " if i%2==1 else " "))
    if status_label and not game_over:
        status_label.text = "Check!" if _in_check(turn, board) else "Select a piece to see its legal moves."

func _on_square(sq: Vector2i) -> void:
    if game_over or thinking:
        return
    if selected.x >= 0 and sq in legal_targets:
        _make_move(selected, sq)
        return
    var p: String = board[sq.x][sq.y]
    if p != "" and p.begins_with(turn):
        selected = sq
        legal_targets = _legal_moves(sq, board)
    else:
        selected = Vector2i(-1,-1)
        legal_targets.clear()
    _refresh_board()

func _make_move(a: Vector2i, b: Vector2i, promotion := "Q") -> void:
    var snapshot := {"board":board.duplicate(true),"turn":turn,"ep":en_passant,"castle":castle.duplicate(true),"w":white_seconds,"b":black_seconds,"log":move_log.duplicate()}
    history.append(var_to_str(snapshot))
    var piece: String = board[a.x][a.y]
    var captured: String = board[b.x][b.y]
    var notation := _square_name(a) + _square_name(b)
    if piece.substr(1,1) == "P" and b == en_passant and captured == "":
        board[a.x][b.y] = ""
        captured = "x"
    if piece.substr(1,1) == "K" and abs(b.y-a.y)==2:
        if b.y > a.y:
            board[a.x][5] = board[a.x][7]
            board[a.x][7] = ""
        else:
            board[a.x][3] = board[a.x][0]
            board[a.x][0] = ""
    board[b.x][b.y] = piece
    board[a.x][a.y] = ""
    if piece.substr(1,1) == "P" and (b.x == 0 or b.x == 7):
        board[b.x][b.y] = piece.substr(0,1) + promotion
    if piece == "wK": castle["wK"]=false; castle["wQ"]=false
    if piece == "bK": castle["bK"]=false; castle["bQ"]=false
    if a == Vector2i(7,0): castle["wQ"]=false
    if a == Vector2i(7,7): castle["wK"]=false
    if a == Vector2i(0,0): castle["bQ"]=false
    if a == Vector2i(0,7): castle["bK"]=false
    en_passant = Vector2i(-1,-1)
    if piece.substr(1,1)=="P" and abs(b.x-a.x)==2:
        en_passant = Vector2i((a.x+b.x)/2,a.y)
    move_log.append(notation + (" x" if captured != "" else ""))
    selected = Vector2i(-1,-1)
    legal_targets.clear()
    turn = "b" if turn=="w" else "w"
    _refresh_board()
    _check_end()
    if vs_computer and not game_over and turn == computer_side:
        _computer_move()

func _square_name(s: Vector2i) -> String:
    return "abcdefgh".substr(s.y,1) + str(8-s.x)

func _legal_moves(sq: Vector2i, pos: Array) -> Array[Vector2i]:
    var pseudo := _pseudo_moves(sq,pos)
    var out: Array[Vector2i] = []
    var side: String = pos[sq.x][sq.y].substr(0,1)
    for dst in pseudo:
        var test := pos.duplicate(true)
        _apply_simple(test,sq,dst)
        if not _in_check(side,test):
            out.append(dst)
    return out

func _pseudo_moves(sq: Vector2i, pos: Array) -> Array[Vector2i]:
    var out: Array[Vector2i] = []
    var p: String = pos[sq.x][sq.y]
    if p == "": return out
    var side := p.substr(0,1)
    var kind := p.substr(1,1)
    var dirs: Array[Vector2i] = []
    if kind == "P":
        var d := -1 if side=="w" else 1
        var one := Vector2i(sq.x+d,sq.y)
        if _inside(one) and pos[one.x][one.y]=="":
            out.append(one)
            var two := Vector2i(sq.x+2*d,sq.y)
            if (sq.x==6 and side=="w" or sq.x==1 and side=="b") and pos[two.x][two.y]=="":
                out.append(two)
        for dc in [-1,1]:
            var cap := Vector2i(sq.x+d,sq.y+dc)
            if _inside(cap):
                if pos[cap.x][cap.y]!="" and not pos[cap.x][cap.y].begins_with(side):
                    out.append(cap)
                elif cap == en_passant:
                    out.append(cap)
    elif kind == "N":
        for d in [Vector2i(-2,-1),Vector2i(-2,1),Vector2i(-1,-2),Vector2i(-1,2),Vector2i(1,-2),Vector2i(1,2),Vector2i(2,-1),Vector2i(2,1)]:
            _add_if_available(out,sq+d,side,pos)
    elif kind == "K":
        for dx in [-1,0,1]:
            for dy in [-1,0,1]:
                if dx!=0 or dy!=0: _add_if_available(out,sq+Vector2i(dx,dy),side,pos)
        if side=="w" and sq==Vector2i(7,4) and not _in_check("w",pos):
            if castle.wK and pos[7][5]=="" and pos[7][6]=="" and not _is_attacked(Vector2i(7,5),"b",pos) and not _is_attacked(Vector2i(7,6),"b",pos): out.append(Vector2i(7,6))
            if castle.wQ and pos[7][1]=="" and pos[7][2]=="" and pos[7][3]=="" and not _is_attacked(Vector2i(7,3),"b",pos) and not _is_attacked(Vector2i(7,2),"b",pos): out.append(Vector2i(7,2))
        if side=="b" and sq==Vector2i(0,4) and not _in_check("b",pos):
            if castle.bK and pos[0][5]=="" and pos[0][6]=="" and not _is_attacked(Vector2i(0,5),"w",pos) and not _is_attacked(Vector2i(0,6),"w",pos): out.append(Vector2i(0,6))
            if castle.bQ and pos[0][1]=="" and pos[0][2]=="" and pos[0][3]=="" and not _is_attacked(Vector2i(0,3),"w",pos) and not _is_attacked(Vector2i(0,2),"w",pos): out.append(Vector2i(0,2))
    else:
        if kind=="R" or kind=="Q": dirs += [Vector2i(-1,0),Vector2i(1,0),Vector2i(0,-1),Vector2i(0,1)]
        if kind=="B" or kind=="Q": dirs += [Vector2i(-1,-1),Vector2i(-1,1),Vector2i(1,-1),Vector2i(1,1)]
        for d in dirs:
            var cur := sq+d
            while _inside(cur):
                if pos[cur.x][cur.y]=="":
                    out.append(cur)
                else:
                    if not pos[cur.x][cur.y].begins_with(side): out.append(cur)
                    break
                cur += d
    return out

func _add_if_available(out: Array[Vector2i], dst: Vector2i, side: String, pos: Array) -> void:
    if _inside(dst) and (pos[dst.x][dst.y]=="" or not pos[dst.x][dst.y].begins_with(side)):
        out.append(dst)

func _inside(s: Vector2i) -> bool:
    return s.x>=0 and s.x<8 and s.y>=0 and s.y<8

func _apply_simple(pos: Array, a: Vector2i, b: Vector2i) -> void:
    var p: String = pos[a.x][a.y]
    if p.substr(1,1)=="P" and b==en_passant and pos[b.x][b.y]=="":
        pos[a.x][b.y]=""
    if p.substr(1,1)=="K" and abs(b.y-a.y)==2:
        if b.y==6: pos[a.x][5]=pos[a.x][7]; pos[a.x][7]=""
        else: pos[a.x][3]=pos[a.x][0]; pos[a.x][0]=""
    pos[b.x][b.y]=p
    pos[a.x][a.y]=""
    if p.substr(1,1)=="P" and (b.x==0 or b.x==7):
        pos[b.x][b.y]=p.substr(0,1)+"Q"

func _in_check(side: String, pos: Array) -> bool:
    var king := Vector2i(-1,-1)
    for r in range(8):
        for c in range(8):
            if pos[r][c] == side+"K": king=Vector2i(r,c)
    if king.x<0: return true
    return _is_attacked(king,"b" if side=="w" else "w",pos)

func _is_attacked(sq: Vector2i, by_side: String, pos: Array) -> bool:
    for r in range(8):
        for c in range(8):
            var p: String = pos[r][c]
            if p=="" or p.substr(0,1)!=by_side: continue
            var kind := p.substr(1,1)
            var dr := sq.x-r
            var dc := sq.y-c
            if kind=="P":
                var d := -1 if by_side=="w" else 1
                if dr==d and abs(dc)==1: return true
            elif kind=="N":
                if abs(dr)*abs(dc)==2: return true
            elif kind=="K":
                if max(abs(dr),abs(dc))==1: return true
            else:
                var diagonal := abs(dr)==abs(dc)
                var straight := dr==0 or dc==0
                if (kind=="B" and not diagonal) or (kind=="R" and not straight) or (kind=="Q" and not diagonal and not straight): continue
                var step := Vector2i(sign(dr),sign(dc))
                var cur := Vector2i(r,c)+step
                var blocked := false
                while cur != sq:
                    if pos[cur.x][cur.y]!="": blocked=true; break
                    cur += step
                if not blocked: return true
    return false

func _all_legal(side: String, pos: Array) -> Array:
    var moves := []
    for r in range(8):
        for c in range(8):
            if pos[r][c]!="" and pos[r][c].begins_with(side):
                for dst in _legal_moves(Vector2i(r,c),pos):
                    moves.append([Vector2i(r,c),dst])
    return moves

func _check_end() -> void:
    var moves := _all_legal(turn,board)
    if moves.is_empty():
        game_over = true
        clock_running = false
        if _in_check(turn,board):
            status_label.text = ("WHITE" if turn=="b" else "BLACK") + " WINS BY CHECKMATE"
        else:
            status_label.text = "DRAW BY STALEMATE"
    elif _in_check(turn,board):
        status_label.text = "CHECK — KING IS UNDER ATTACK"

func _computer_move() -> void:
    thinking = true
    _refresh_board()
    await get_tree().create_timer(0.35).timeout
    var moves := _all_legal(computer_side,board)
    if moves.is_empty():
        thinking=false
        _check_end()
        return
    var best_move = moves[0]
    var best_score := -999999.0
    for m in moves:
        var test := board.duplicate(true)
        var captured: String = test[m[1].x][m[1].y]
        _apply_simple(test,m[0],m[1])
        var score := _evaluate(test,computer_side)
        if captured!="": score += float(VALUES[captured.substr(1,1)]) * 0.8
        score += randf()*12.0
        if score > best_score:
            best_score=score
            best_move=m
    thinking = false
    _make_move(best_move[0],best_move[1])

func _evaluate(pos: Array, side: String) -> float:
    var score := 0.0
    for r in range(8):
        for c in range(8):
            var p: String = pos[r][c]
            if p=="" : continue
            var value := float(VALUES[p.substr(1,1)])
            var centre := 3.5 - (abs(3.5-r)+abs(3.5-c))*0.08
            value += centre * (10 if p.substr(1,1)=="N" or p.substr(1,1)=="B" else 2)
            score += value if p.begins_with(side) else -value
    return score

func _undo() -> void:
    if history.is_empty(): return
    var snap: Dictionary = str_to_var(history.pop_back())
    board=snap.board
    turn=snap.turn
    en_passant=snap.ep
    castle=snap.castle
    white_seconds=snap.w
    black_seconds=snap.b
    move_log=snap.log
    game_over=false
    thinking=false
    selected=Vector2i(-1,-1)
    legal_targets.clear()
    if vs_computer and turn==computer_side and not history.is_empty():
        _undo()
        return
    _refresh_board()

func _hint() -> void:
    var moves := _all_legal(turn,board)
    if moves.is_empty(): return
    var chosen = moves[randi_range(0,moves.size()-1)]
    selected=chosen[0]
    legal_targets=[chosen[1]]
    status_label.text = "Hint: " + _square_name(chosen[0]) + " → " + _square_name(chosen[1])
    _refresh_board()

func _resign() -> void:
    game_over=true
    clock_running=false
    status_label.text = ("BLACK" if turn=="w" else "WHITE") + " WINS BY RESIGNATION"

func _clock_text(seconds: float) -> String:
    var s := int(max(0,seconds))
    return "%02d:%02d" % [s/60,s%60]

func _process(delta: float) -> void:
    if page!="game" or not clock_running or game_over or thinking: return
    if turn=="w": white_seconds=max(0,white_seconds-delta)
    else: black_seconds=max(0,black_seconds-delta)
    if int(white_seconds)==0 or int(black_seconds)==0:
        game_over=true
        clock_running=false
        status_label.text = "TIME OUT — " + ("BLACK" if white_seconds<=0 else "WHITE") + " WINS"
    if int(Engine.get_process_frames())%15==0:
        _refresh_clock_labels()

func _refresh_clock_labels() -> void:
    # Clock labels are intentionally lightweight; full UI refresh is avoided every frame.
    pass

func _academy() -> void:
    _simple_page("CHESS ACADEMY", "A structured offline learning path", [
        "01  Board coordinates and how each piece moves",
        "02  Check, checkmate, stalemate and draw rules",
        "03  Opening principles: centre, development, king safety",
        "04  Tactics: forks, pins, skewers and discovered attacks",
        "05  Strategy: pawn structure, weak squares and plans",
        "06  Essential king and pawn endgames",
        "07  Candidate moves and calculation habits",
        "08  Review your games and learn from mistakes"
    ])

func _puzzles() -> void:
    _simple_page("TACTICS TRAINING", "Choose a theme to practise. Puzzle packs can be expanded with additional positions.", [
        "FORKS  •  Attack two targets at once",
        "PINS  •  Restrict a piece behind a valuable target",
        "SKEWERS  •  Win material with a line attack",
        "DISCOVERED ATTACKS  •  Reveal a hidden attacker",
        "MATE PATTERNS  •  Back rank and basic mating nets",
        "ENDGAMES  •  Opposition and pawn promotion"
    ])

func _simple_page(title: String, subtitle: String, lines: Array) -> void:
    page="info"
    _clear()
    _button(screen_root,"← DASHBOARD",Vector2(45,55),Vector2(280,60),_show_home)
    _label(screen_root,title,Vector2(45,220),Vector2(990,70),39,GOLD,HORIZONTAL_ALIGNMENT_CENTER)
    _label(screen_root,subtitle,Vector2(60,300),Vector2(960,55),20,Color("#d9d5cc"),HORIZONTAL_ALIGNMENT_CENTER)
    for i in range(lines.size()):
        _panel(screen_root,Vector2(65,420+i*145),Vector2(950,105))
        _label(screen_root,lines[i],Vector2(95,430+i*145),Vector2(890,85),20,Color("#f1eee7"))

func _themes() -> void:
    page="info"
    _clear()
    _button(screen_root,"← DASHBOARD",Vector2(45,55),Vector2(280,60),_show_home)
    _label(screen_root,"THEME STUDIO",Vector2(50,220),Vector2(980,75),40,GOLD,HORIZONTAL_ALIGNMENT_CENTER)
    for i in range(theme_names.size()):
        var name: String = theme_names[i]
        _button(screen_root,name,Vector2(80+(i%2)*500,420+int(i/2)*140),Vector2(440,90),func(): _choose_theme(name),name==theme_name)

func _choose_theme(name: String) -> void:
    theme_name=name
    match name:
        "EMERALD": theme_accent=Color("#71d6a4")
        "PURPLE": theme_accent=Color("#c49aff")
        "WOOD": theme_accent=Color("#d69a5b")
        "AMOLED BLACK": theme_accent=Color("#5bd8d0")
        _: theme_accent=GOLD
    _themes()

func _stats() -> void:
    _simple_page("PLAYER STATS","Local profile overview",[
        "Games played: " + str(move_log.size()/2),
        "Current session: offline",
        "Training path: beginner → intermediate → advanced",
        "Game history and rating ledger: available in a future save-data update"
    ])

func _settings() -> void:
    page="info"
    _clear()
    _button(screen_root,"← DASHBOARD",Vector2(45,55),Vector2(280,60),_show_home)
    _label(screen_root,"SETTINGS",Vector2(50,220),Vector2(980,75),40,GOLD,HORIZONTAL_ALIGNMENT_CENTER)
    _label(screen_root,"Opponent strength",Vector2(100,390),Vector2(880,55),24)
    _button(screen_root,"EASY",Vector2(100,470),Vector2(250,75),func(): _set_difficulty(1))
    _button(screen_root,"NORMAL",Vector2(410,470),Vector2(250,75),func(): _set_difficulty(2),true)
    _button(screen_root,"HARD",Vector2(720,470),Vector2(250,75),func(): _set_difficulty(3))
    _button(screen_root,"TOGGLE SOUND  •  " + ("ON" if sound_on else "OFF"),Vector2(150,610),Vector2(780,80),func(): sound_on=!sound_on; _settings())
    _button(screen_root,"COMPUTER OPPONENT: " + ("ON" if vs_computer else "OFF"),Vector2(150,730),Vector2(780,80),func(): vs_computer=!vs_computer; _settings())

func _set_difficulty(value: int) -> void:
    difficulty=value
    _settings()
