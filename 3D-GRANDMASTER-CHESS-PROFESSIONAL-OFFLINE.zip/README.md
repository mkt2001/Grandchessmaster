# 3D GRANDMASTER CHESS — OFFLINE

Godot 4.3 Android project. Online multiplayer, matchmaking, accounts, chat, cloud saves and server dependencies are deliberately excluded.

## Implemented in this package
- Welcome screen and offline dashboard
- Interactive chessboard with selectable pieces and legal destination highlighting
- Local chess rules: standard piece movement, captures, check validation, castling, en-passant, queen promotion, checkmate and stalemate detection
- Built-in offline computer opponent (material/position evaluation, lightweight move selection)
- Local two-player mode toggle
- 10-minute clocks, undo, hint and resignation controls
- Learning roadmap and tactical training categories
- Theme studio and basic settings
- Android debug export preset and GitHub Actions workflow

## Honest limitations
- The computer opponent is a lightweight built-in heuristic, not Stockfish; difficulty selector is a UI setting and does not yet change search depth.
- The board is a polished 2D touch board in this build, not a photorealistic 3D board. This is intentional to deliver a responsive, playable Android chess core without requiring large external art assets.
- Chess960, blindfold, dedicated bullet/blitz/rapid time presets, puzzle positions with answer validation, persistent profiles, PGN/FEN import/export, voice coaching, 3D piece assets/animations and full audio are not implemented yet.
- Promotion currently defaults to a queen. The clock display is initialized but not yet dynamically refreshed in the HUD.
- The project has not been tested on a physical Android device from this environment. Run the GitHub Action and install the generated debug APK to validate on your phone.

## Build
1. Create an empty GitHub repository.
2. Extract this ZIP and upload all contained files and folders to the repository root.
3. Go to **Actions** and run **Build Android APK** (or push to `main`).
4. Download artifact **3D-Grandmaster-Chess-APK** from the workflow run.

The workflow builds a debug APK for arm64 Android. A Play Store release requires a signing keystore and release configuration.
